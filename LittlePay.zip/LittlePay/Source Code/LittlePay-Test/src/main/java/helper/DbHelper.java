
package helper;

/**
 * @author stefanuskj
 *
 */
public class DbHelper {
	//Usually this class file will contain function that will be used by other class to do CRUD operation on the database
}
