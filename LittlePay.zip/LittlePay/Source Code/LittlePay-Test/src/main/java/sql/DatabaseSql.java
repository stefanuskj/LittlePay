/**
 * 
 */
package sql;

/**
 * @author demon
 *
 */
public class DatabaseSql {
	//This class will contain all the SQL Syntax that will be use by DbHelper.java
}
